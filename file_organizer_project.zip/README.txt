AUTOMATIC FILE ORGANIZER
=========================

How to run:
1. Make sure Python 3 is installed.
2. Open Command Prompt/Terminal in this folder.
3. Run:

   python file_organizer.py

4. Enter the full path of the folder you want to organize.
5. Type y when asked for confirmation.

The program creates:
- Images
- Documents
- Videos
- Audio
- Archives
- Others

It moves files based on their extensions and does NOT permanently
delete files. Existing files are protected from overwriting by
automatically creating names such as file_1.jpg and file_2.jpg.

Modules demonstrated:
- os
- pathlib
- shutil
