import os
from pathlib import Path
import shutil

IMAGE_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp",
    ".webp", ".svg", ".tiff", ".ico"
}

DOCUMENT_EXTENSIONS = {
    ".pdf", ".doc", ".docx", ".txt", ".rtf",
    ".odt", ".xls", ".xlsx", ".csv", ".ppt", ".pptx"
}

VIDEO_EXTENSIONS = {
    ".mp4", ".mkv", ".avi", ".mov",
    ".wmv", ".flv", ".webm", ".mpeg"
}

AUDIO_EXTENSIONS = {
    ".mp3", ".wav", ".aac", ".flac",
    ".ogg", ".m4a", ".wma"
}

ARCHIVE_EXTENSIONS = {
    ".zip", ".rar", ".7z", ".tar",
    ".gz", ".bz2"
}


def get_category(file_extension):
    """Return the folder category for a file extension."""
    extension = file_extension.lower()

    if extension in IMAGE_EXTENSIONS:
        return "Images"
    elif extension in DOCUMENT_EXTENSIONS:
        return "Documents"
    elif extension in VIDEO_EXTENSIONS:
        return "Videos"
    elif extension in AUDIO_EXTENSIONS:
        return "Audio"
    elif extension in ARCHIVE_EXTENSIONS:
        return "Archives"
    else:
        return "Others"


def create_folders(folder_path):
    """Create all category folders if they do not already exist."""
    categories = [
        "Images", "Documents", "Videos",
        "Audio", "Archives", "Others"
    ]

    for category in categories:
        (folder_path / category).mkdir(exist_ok=True)


def get_unique_destination(destination):
    """Avoid overwriting an existing file."""
    if not destination.exists():
        return destination

    counter = 1
    while True:
        new_name = (
            destination.stem
            + "_"
            + str(counter)
            + destination.suffix
        )
        new_destination = destination.parent / new_name

        if not new_destination.exists():
            return new_destination

        counter += 1


def organize_files(folder_path):
    """Move files into folders based on their extensions."""
    moved_files = {
        "Images": [],
        "Documents": [],
        "Videos": [],
        "Audio": [],
        "Archives": [],
        "Others": []
    }

    error_files = []

    print("\nScanning folder...")
    print("-" * 60)

    with os.scandir(folder_path) as entries:
        for entry in entries:
            if not entry.is_file():
                continue

            source_file = Path(entry.path)
            category = get_category(source_file.suffix)
            destination_folder = folder_path / category
            destination = get_unique_destination(
                destination_folder / source_file.name
            )

            try:
                shutil.move(str(source_file), str(destination))
                moved_files[category].append(source_file.name)

                print(
                    f"Moved: {source_file.name} "
                    f"--> {category}"
                )

            except PermissionError:
                print(f"Permission denied: {source_file.name}")
                error_files.append(source_file.name)

            except OSError as error:
                print(
                    f"Could not move {source_file.name}: {error}"
                )
                error_files.append(source_file.name)

            except Exception as error:
                print(
                    f"Unexpected error with "
                    f"{source_file.name}: {error}"
                )
                error_files.append(source_file.name)

    return moved_files, error_files


def display_summary(moved_files, error_files):
    """Display a summary of moved files."""
    print("\n" + "=" * 60)
    print("              FILE ORGANIZATION SUMMARY")
    print("=" * 60)

    total_files = 0

    for category, files in moved_files.items():
        count = len(files)
        total_files += count

        print(f"\n{category}: {count} file(s)")

        for file_name in files:
            print(f"   - {file_name}")

    print("\n" + "-" * 60)
    print(f"Total files moved: {total_files}")
    print(f"Files with errors: {len(error_files)}")

    if error_files:
        for file_name in error_files:
            print(f"   - {file_name}")

    print("-" * 60)
    print("No files were permanently deleted.")
    print("=" * 60)


def main():
    print("=" * 60)
    print("             AUTOMATIC FILE ORGANIZER")
    print("=" * 60)

    print("\nThis program organizes files according to")
    print("their extensions.")
    print("\nExamples:")
    print("  .jpg  -> Images")
    print("  .pdf  -> Documents")
    print("  .mp4  -> Videos")
    print("  .mp3  -> Audio")
    print("  .zip  -> Archives")
    print("  unknown -> Others")

    folder_input = input(
        "\nEnter the full path of the folder to organize: "
    ).strip()

    folder_input = folder_input.strip('"').strip("'")
    folder_path = Path(folder_input)

    if not folder_path.exists():
        print("\nError: The specified path does not exist.")
        return

    if not folder_path.is_dir():
        print("\nError: The specified path is not a directory.")
        return

    folder_path = folder_path.resolve()

    print(f"\nSelected folder: {folder_path}")

    confirmation = input(
        "\nDo you want to organize these files? (y/n): "
    ).lower().strip()

    if confirmation != "y":
        print("\nOperation cancelled by user.")
        return

    create_folders(folder_path)

    moved_files, error_files = organize_files(folder_path)

    display_summary(moved_files, error_files)

    print("\nFile organization completed successfully.")


if __name__ == "__main__":
    main()
